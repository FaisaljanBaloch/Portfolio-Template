** English will follow **

Dans Purrfect Escape, nous endossons le rôle d'un chat désireux de sortir afin 
de satisfaire ses instincts de chasseur. Cependant, celui-ci est prisonnier de 
sa maison et ses humains ne le laisse pas sortir. Peut-il trouver un moyen de s'échapper?

Contrôles:
Marcher: W, A, S, D
Courir: L-Shift + Marcher
Accroupir: L-Ctrl
Sauter: Espace
Camera: Souris

-------------------------------------------------------------------------

In Purrfect Escape, we take on the role of a cat who is eager to go outside in 
order to satisfy his hunting instincts. However, this one is a prisoner of his 
house and his humans will not let him out. Can he find a way to escape?

Controls:
Walk: W, A, S, D
Run: L-Shift + Walk
Crouch: L-Ctrl
Jump: Space
Camera: Mouse