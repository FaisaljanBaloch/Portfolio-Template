** English will follow **

Pour démarrer le jeu, vous devez l'ajouter à Steam 
 - Cliquez sur le bouton ajouter un jeu > ajouter un jeu non Steam dans l'onglet bibliothèque. 
 - Sélectionnez l'exécutable BackToTheParty.exe 
 - Cliquez sur le bouton ajouter les sélections.

Vous allez maintenant pouvoir démarrer le jeu par Steam. 

Dans le jeu:
 - Entrez votre nom dans le bloc de texte spécifié. Vous pouvez maintenant démarrer une partie. 
 - Un des deux joueurs devra créer un salon avec le bouton Host Game. 

Une fois ce salon créé, le deuxième joueur pourra le rejoindre avec le bouton join game.
Entrez le nom du joueur que vous voulez rejoindre dans le bloc de texte spécifié. 

Pour plus d'informations, consultez la section How To Play dans le salon.

Vous pouvez maintenant jouer!

Bonne chance!

---------------------------------------------------------------------------

To start the game, you need to add it to Steam
  - Click the add game button > add non-Steam game in the library tab.
  - Select the BackToTheParty.exe executable
  - Click on the add selections button.

You will now be able to start the game through Steam.

In the game:
  - Enter your name in the specified text block. You can now start a game.
  - One of the two players will have to create a room with the Host Game button.

Once this room has been created, the second player can join it with the join game button.
Enter the name of the player you want to join in the specified text block.

For more information, see the How To Play section in the living room.

You can now play!

Good luck!