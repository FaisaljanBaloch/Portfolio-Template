** English will follow **

Dans ElemEnsions, vous incarnez Guerna la gobeline aventurière à la recherche d'un nouveau trésor. 
Afin de surmonter les nombreux obstacles des ruines, vous avez à votre disposition le pouvoir 
du pendentif de Portalite, artéfact trouvé lors d'une aventure passée, qui permet de changer 
d'une dimension élémentaire à une autre. Chaque élément a ses propriétés uniques:  
Feu, Air, Eau, Terre. 

Contrôles: 
WASD = Bouger, 
ESPACE = Sauter, 
MAJ = Sprint (Feu), 
E = Interagir/Ramasser, 
Q = Lâcher, 
1234 = Changer de dimension (nécessite un jeton de passage instantané)

Pouvoirs:
Air: Double saut et glide, 
Eau: Marcher sur l'eau, 
Terre: Sauts muraux, 
Feu: torches et sprint

-------------------------------------------------------------------------

In ElemEnsions, you play as Guerna the adventurous goblin in search of a new treasure.
In order to overcome the many obstacles of the ruins, you have at your disposal the power
the Portalite pendant, an artifact found during a past adventure, which allows you to change
from one elementary dimension to another. Each element has its unique properties:
Fire, Air, Water, Earth.

Controls:
WASD = Move,
SPACE = Jump,
SHIFT = Sprint (Fire),
E = Interact/Pick up,
Q = Release,
1234 = Change Dimension (requires instant pass token)

Powers:
Air: Double jump and glide,
Water: Walking on water,
Earth: Wall jumps,
Fire: torches and sprint